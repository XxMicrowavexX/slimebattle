# Godot Simple Networking

A simple Godot networking system for connecting to an online server, spawning players, and updating positions.
